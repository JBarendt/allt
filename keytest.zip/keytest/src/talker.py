#!/usr/bin/env python

import rospy
from keytest.msg import drive_values
from keytest.msg import drive_param
from std_msgs.msg import Bool


"""
What you should do:
 1. Subscribe to the keyboard messages (If you use the default keyboard.py, you must subcribe to "drive_paramters" which is publishing messages of "drive_param")
 2. Map the incoming values to the needed PWM values
 3. Publish the calculated PWM values on topic "drive_pwm" using custom message drive_values
"""
def callback(data):
    print "Velocity: %s Angle: %s" %(data.velocity, data.angle)
    pub = rospy.Publisher('drive_pwm', drive_values, queue_size=10)
    msg = drive_values()
    msg.pwm_drive = mapPWM(data.velocity)
    msg.pwm_angle = mapPWM(data.angle)
    pub.publish(msg)

def mapPWM(value):
    valueScaled = float(value - (-10)) / float(20)
    return 6554 + (valueScaled * 6554)
def talker():
    rospy.init_node('talker', anonymous=True)

    rospy.Subscriber('drive_parameters', drive_param, callback)



    rospy.spin()

if __name__ == '__main__':
    talker()
